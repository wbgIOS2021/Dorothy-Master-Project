//
//  ProductListViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 15/07/21.
//

import UIKit
import Kingfisher

class ProductListViewController: UIViewController {

    @IBOutlet weak var categoryCollectionView: UICollectionView!
    @IBOutlet weak var noDataAvailableView: UIView!
    @IBOutlet weak var itemsTableView: UITableView!
    @IBOutlet weak var categoryNameLabel: UILabel!
    @IBOutlet weak var cartBtn: UIBarButtonItem!

    var category_listArray: [[String:Any]] = []
    var product_listArray: [[String:Any]] = []

    var category_id:String = ""
    var bolValue:[Bool] = []
    var selectedIndex = 0
    var categoryName:String = ""
    let user_id = (getStringValueFromLocal(key: "user_id") ?? "0")
    override func viewDidLoad() {
        super.viewDidLoad()
        cellRegister()
        categoryCollectionView.dataSource = self
        categoryCollectionView.delegate = self
        itemsTableView.dataSource = self
        itemsTableView.delegate = self
        
        for _ in 0..<category_listArray.count{
            bolValue.append(false)
        }
        bolValue[selectedIndex] = true
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        self.noDataAvailableView.isHidden = true
        gettingData(category_id: category_id)
        cartCount(cartBtn: cartBtn)
    }
    override func viewDidLayoutSubviews() {
//        categoryCollectionView.scrollToItem(at:IndexPath(item: selectedIndex, section: 0), at: .left, animated: false)
        UIView.animate(withDuration: 1, animations: { [weak self] in
            self?.categoryCollectionView.scrollToItem(at: IndexPath(item: self!.selectedIndex, section: 0), at: .centeredHorizontally, animated: false)
        })
        
    }
    // Registering cell data
    func cellRegister()
    {
        // Collection view
        categoryCollectionView.register(UINib(nibName: "SmallCategoriesCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "SmallCategoriesCollectionViewCell")
        
        //Table view
        itemsTableView.register(UINib(nibName: "ProductTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductTableViewCell")
    }
    
    
    
}

//MARK:- MARK:- Navigation Action Buttons
extension ProductListViewController
{
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    @IBAction func searchBtn(_ sender: Any) {
        searchBtn()
    }
    @IBAction func cartBtn(_ sender: Any) {
        cartBtn()
    }
}

//MARK:- Collection view Data Source
extension ProductListViewController: UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return category_listArray.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = categoryCollectionView.dequeueReusableCell(withReuseIdentifier: "SmallCategoriesCollectionViewCell", for: indexPath) as! SmallCategoriesCollectionViewCell
        
        let cellData = category_listArray[indexPath.row]
        let url = URL(string: cellData["image"] as! String)
        cell.categoryImage.kf.setImage(with: url, placeholder: UIImage(named: "beef"))
        cell.categoryName!.text! = cellData["title"] as! String
       
        if bolValue[indexPath.row]
        {
            //cell.data = data["type"] as! [String]
            print("bolValue4--------------",bolValue)
           // cell.subTableView.reloadData()
            cell.categoryView.layer.backgroundColor = #colorLiteral(red: 0.9971496463, green: 0.8193712831, blue: 0.07595702261, alpha: 1)
            selectedIndex = indexPath.row
        }else{
            cell.categoryView.layer.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)

        }
        return cell
    }
}

//MARK:- Collection view Delegate
extension ProductListViewController: UICollectionViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = categoryCollectionView.cellForItem(at: indexPath) as! SmallCategoriesCollectionViewCell
        
        title = "\(category_listArray[indexPath.row]["title"]!)"
        let category_ids = "\(category_listArray[indexPath.row]["id"]!)"
        gettingData(category_id: category_ids)
        
        if bolValue[indexPath.row]{
            for x in 0..<bolValue.count{
                 if x == indexPath.row{
                     bolValue[x] = true
                 }
                 }
        }else{
            for x in 0..<bolValue.count{
                 if x == indexPath.row{
                     bolValue[x] = true
                 }
                 else{
                    bolValue[x] = false
                 }
            }
        }

        categoryCollectionView.reloadData()
    
    }
}

//MARK:- Collection
extension ProductListViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("--------------------------------------->>>>",product_listArray.count)
        return product_listArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = itemsTableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
        
        let cellData = product_listArray[indexPath.row]
        let url = URL(string: cellData["thumb"] as! String)
        cell.productImage.kf.setImage(with: url, placeholder: UIImage(named: "bbq"))
        cell.productName!.text! = cellData["name"] as! String
        cell.productweight!.text! = "\(cellData["description"] as! String)"
        if cellData["special"] as! String == "0.00" || cellData["special"] as! String == "0" || cellData["special"] as! String == cellData["price"] as! String{
            cell.specialPrice!.text! = "$ \(cellData["price"] as! String)"
            cell.productPrice.isHidden = true
        }else{
            cell.productPrice!.text! = "$ \(cellData["price"] as! String)"
            cell.specialPrice!.text! = "$ \(cellData["special"] as! String)"
        }
        if cellData["isWishlist"] as! String == "1"{
            cell.likeBtn.setBackgroundImage(UIImage(named: "Vector (8)"), for: .normal)
        }else{
            cell.likeBtn.setBackgroundImage(UIImage(named: "Vector (4)"), for: .normal)
        }
        cell.likeBtn.tag = indexPath.row
        cell.likeBtn.addTarget(self, action: #selector(self.wishlistCheck), for: .touchUpInside)
        cell.addToCartBtn.tag = indexPath.row
        cell.addToCartBtn.addTarget(self, action: #selector(self.productsAddToCart), for: .touchUpInside)

        return cell
    }
    
    @objc func wishlistCheck(_ sender: UIButton)
    {
        let list =  product_listArray[sender.tag]
        let success:successHandler = {  response in
            let json = response as! [String : Any]
            let cell = self.itemsTableView.cellForRow(at: NSIndexPath(row: sender.tag, section: 0) as IndexPath) as! ProductTableViewCell
            if json["responseStatus"] as! String == "1"
            {
                cell.likeBtn.setBackgroundImage(UIImage(named: "Vector (8)"), for: .normal)
            }else{
                cell.likeBtn.setBackgroundImage(UIImage(named: "Vector (4)"), for: .normal)
            }
        }
        
        self.wishlistAction(product_id: list["productId"] as! String,actionHandler:success)
    }
    //Add to cart Action
    @objc func productsAddToCart(_ sender:UIButton)
    {
        let product =  product_listArray[sender.tag]
        addCart2(product:product,cartBtn:cartBtn)
    }
}
//MARK:- Table View Delegate
extension ProductListViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vC = storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        vC.productId = product_listArray[indexPath.row]["productId"] as! String
        navigationController?.pushViewController(vC, animated: true)
        }
        
}

//MARK:- API Calling
extension ProductListViewController
{
    func gettingData(category_id:String) -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in

        let json = response as! [String : Any]
        self.product_listArray.removeAll()
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as? [[String : Any]]
            self.categoryName = json["categoryName"]  as! String
            let cartItemTotal = json["cartItemTotal"]  as! String
            let minPrice = json["minPrice"]  as! String
            let maxPrice = json["maxPrice"]  as! String
            
            for data in responseData!
                {
                    
                    let productId = data["productId"] as! String
                    let thumb = data["thumb"] as! String
                    let name = data["name"] as! String
                    let description = data["description"] as! String
                    let price = data["price"] as! String
                    let special = data["special"] as! String
                    let specialInNumber = data["specialInNumber"] as! String
                    
                    let tax = data["tax"] as! String
                    let rating = data["rating"] as! String
                    let minimum = data["minimum"] as! String
                    let stockStatusId = data["stockStatusId"] as! String
                    
                    let stockStatus = data["stockStatus"] as! String
                    let manufacturerId = data["manufacturerId"] as! String
                    let optionCount = data["optionCount"] as! String
                    let isWishlist = data["isWishlist"] as! String
                    
                
                let dic:[String : Any] = ["productId":productId,"thumb":thumb,"name":name,"description":description,"price":price,"special":special,"specialInNumber":specialInNumber,"tax":tax,"rating":rating,"minimum":minimum,"stockStatusId":stockStatusId,"stockStatus":stockStatus,"manufacturerId":manufacturerId,"optionCount":optionCount,"isWishlist":isWishlist]

                    self.product_listArray.append(dic)
                }
            
                
                //Reloading Table Views And Collection View
                DispatchQueue.main.async
                {
                    if !self.product_listArray.isEmpty{
                        self.noDataAvailableView.isHidden = true
                    }
                    ProgressHud.hide()
                    self.categoryNameLabel.isHidden = false
                    self.categoryNameLabel.text! = self.categoryName
                    UIView.animate(withDuration: 1, animations: { [weak self] in
                        self?.categoryCollectionView.scrollToItem(at: IndexPath(item: self!.selectedIndex, section: 0), at: .centeredHorizontally, animated: false)
                    })
                    
                    self.itemsTableView.reloadData()

                }
        }else{
            DispatchQueue.main.async
            {
            ProgressHud.hide()
//                self.categoryCollectionView.scrollToItem(at:IndexPath(item: self.selectedIndex, section: 0), at: .left, animated: false)
                UIView.animate(withDuration: 1, animations: { [weak self] in
                    self?.categoryCollectionView.scrollToItem(at: IndexPath(item: self!.selectedIndex, section: 0), at: .centeredHorizontally, animated: false)
                })
            if self.product_listArray.isEmpty{
                self.noDataAvailableView.isHidden = false
                self.categoryNameLabel.isHidden = true
            }
                self.itemsTableView.reloadData()
            }
            print("Comming Soon................................")
        }

        }
        
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
               // showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
        }
        
        //Calling API
        let parameters:EIDictonary = ["currency_code": "USD","category_id":category_id,"customer_id": user_id,"is_filter": "1","sort":"2","range_start":"0","range_end":"2000","brand":"6"]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.category_wise_product, successCall: success, failureCall: failure)
    }
}
 

