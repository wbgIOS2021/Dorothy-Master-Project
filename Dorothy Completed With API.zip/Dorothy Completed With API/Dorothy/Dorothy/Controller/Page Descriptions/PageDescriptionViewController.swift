//
//  PageDescriptionViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 23/08/21.
//

import UIKit

class PageDescriptionViewController: UIViewController {

    @IBOutlet weak var textContent: UITextView!
    var page_id:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        gettingData()
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false

    }
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    
}


extension PageDescriptionViewController
{
    func gettingData() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in

        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as! [String : Any]
            
            let page_id = responseData["page_id"] as! String
            let page_title = responseData["page_title"] as! String
            let page_description = responseData["page_description"] as! String
            self.title = page_title
            
           
            self.textContent.text = page_description.htmlToString
            
            
            let htmlString = self.textContent.text!
            
            let data = htmlString.data(using: String.Encoding.unicode)! // mind "!"
            let attrStr = try? NSAttributedString( // do catch
                data: data,
                options: [NSAttributedString.DocumentReadingOptionKey.documentType: NSAttributedString.DocumentType.html],
                documentAttributes: nil)
            
            self.textContent.attributedText = attrStr

//            let newFont = UIFontMetrics.default.scaledFont(for: UIFont.systemFont(ofSize: UIFont.systemFontSize)) // The same is possible for custom font.
//
//            let mattrStr = NSMutableAttributedString(attributedString: attrStr!)
//            mattrStr.beginEditing()
//            mattrStr.enumerateAttribute(.font, in: NSRange(location: 0, length: mattrStr.length), options: .longestEffectiveRangeNotRequired) { (value, range, _) in
//                if let oFont = value as? UIFont, let newFontDescriptor = oFont.fontDescriptor.withFamily(newFont.familyName).withSymbolicTraits(oFont.fontDescriptor.symbolicTraits) {
//                    let nFont = UIFont(descriptor: newFontDescriptor, size: newFont.pointSize)
//                    mattrStr.removeAttribute(.font, range: range)
//                    mattrStr.addAttribute(.font, value: nFont, range: range)
//                }
//            }
//            mattrStr.endEditing()
//            self.textContent.attributedText = mattrStr
                //Reloading Table Views And Collection View
                DispatchQueue.main.async
                {
                    ProgressHud.hide()
                }
        }else{
            ProgressHud.hide()
            print("Comming Soon................................")
        }
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
               // showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
        }
        
        //Calling API
        let parameters:EIDictonary = ["page_id":page_id]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.pageDescription, successCall: success, failureCall: failure)
    }

}


extension String {

    var htmlToAttributedString: NSAttributedString? {

        guard let data = data(using: .utf8) else { return nil }

        do {

            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)

        } catch {

            return nil

        }

    }

    var htmlToString: String {

        return htmlToAttributedString?.string ?? " "

    }

}
