//
//  OrderDetailsViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 19/08/21.
//

import UIKit

class OrderDetailsViewController: UIViewController {

    @IBOutlet weak var orderIdLabel: UILabel!
    @IBOutlet weak var orderDateLabel: UILabel!
    @IBOutlet weak var ordersTableView: UITableView!
    @IBOutlet weak var ordersTableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var statusTableView: UITableView!
    @IBOutlet weak var statusTableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var billingName: UILabel!
    @IBOutlet weak var billingFullAddress: UILabel!
    @IBOutlet weak var statePincode: UILabel!
    @IBOutlet weak var mobile: UILabel!
    @IBOutlet weak var orderMethod: UILabel!
    @IBOutlet weak var totalItems: UILabel!
    @IBOutlet weak var originalPrice: UILabel!
    @IBOutlet weak var discountOnOriginalPrice: UILabel!
    @IBOutlet weak var totalTax: UILabel!
    @IBOutlet weak var deliveryCost: UILabel!
    @IBOutlet weak var finalAmount: UILabel!
   // @IBOutlet weak var status_1Label: UILabel!
   // @IBOutlet weak var expectedByLabel: UILabel!
    @IBOutlet weak var orderCancelbtn: UIButton!
    @IBOutlet weak var orderReOrderBtn: UIButton!
    
    var orderId:String = ""
    var product_listArray: [[String:Any]] = []
    var orderDetails_Array: [String:Any] = [:]
    var Amount_Array: [[String:Any]] = []
    var history_Array: [[String:Any]] = []
    var shippingAddress_Array: [String:Any] = [:]
    var paymentAddress_Array: [String:Any] = [:]
    var user_id = getStringValueFromLocal(key: "user_id") ?? "0"
    var isCancelled:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        cellRegister()
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        gettingData()
        navigationController?.navigationBar.isHidden = false
        self.ordersTableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.statusTableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)

    }
    override func viewWillDisappear(_ animated: Bool) {
        self.ordersTableView.removeObserver(self, forKeyPath: "contentSize")
        self.statusTableView.removeObserver(self, forKeyPath: "contentSize")
        super.viewWillDisappear(true)
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?){
        if let obj = object as? UIScrollView {
            if obj == self.ordersTableView && keyPath == "contentSize" {
                if let newvalue = change?[.newKey]{
                    let newsize  = newvalue as! CGSize
                    self.ordersTableViewHeight.constant = newsize.height
                }
            }else if obj == self.statusTableView && keyPath == "contentSize" {
                if let newvalue = change?[.newKey]{
                    let newsize  = newvalue as! CGSize
                    self.statusTableViewHeight.constant = newsize.height
                }
            }
        }
    }
    func cellRegister()
    {
        //Table view
        ordersTableView.register(UINib(nibName: "OrderDetailsTVC", bundle: nil), forCellReuseIdentifier: "OrderDetailsTVC")
        statusTableView.register(UINib(nibName: "OrderStatusTableViewCell", bundle: nil), forCellReuseIdentifier: "OrderStatusTableViewCell")
    }

    
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    @IBAction func cancelOrder(_ sender: Any) {
        if isCancelled == false{
            cancelOrderAPI()
            self.backBtn()
        }
    }
    @IBAction func reOrderBtn(_ sender: Any) {
        reOrderAPI()
    }
}


extension OrderDetailsViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == statusTableView{
            return history_Array.count
        }
        return  product_listArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == statusTableView{
            let cell = statusTableView.dequeueReusableCell(withIdentifier: "OrderStatusTableViewCell", for: indexPath) as! OrderStatusTableViewCell

            let cellData = history_Array[indexPath.row]
            let dateFormatterGet = DateFormatter()
            dateFormatterGet.dateFormat = "yyyy-MM-dd"

            let dateFormatterPrint = DateFormatter()
            dateFormatterPrint.dateFormat = "E, MMM dd, yyyy"
            let statusDate1: NSDate? = dateFormatterGet.date(from: cellData["date"] as! String) as NSDate?
            cell.statusLabel.text! = "\(cellData["status_name"] as! String)" + " by " + "\(dateFormatterPrint.string(from: statusDate1! as Date))"
            return cell
        }
        let cell = ordersTableView.dequeueReusableCell(withIdentifier: "OrderDetailsTVC", for: indexPath) as! OrderDetailsTVC

        let cellData = product_listArray[indexPath.row]
        let st = cellData["productImage"] as! String
        let urlString = st.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let url = URL(string: urlString!)
        cell.productImage.kf.setImage(with: url, placeholder: UIImage(named: "bbq"))
        cell.productName.text! = cellData["name"] as! String
        cell.productPrice.text! = cellData["total"] as! String
        cell.productQuantity.text! = "Quantity - \(cellData["quantity"] as! String) Pc"
        cell.productSpecialPrice.text! = cellData["price"] as! String
        
        return cell
    }


}

//MARK:- API Calling
extension OrderDetailsViewController
{
    func gettingData() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in

        let json = response as! [String : Any]
        
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as! [String: Any]
            
            let orderNo = responseData["orderNo"] as! String
            let orderDate = responseData["orderDate"] as! String
            let paymentMethod = responseData["paymentMethod"] as! String
            let shippingMethod = responseData["shippingMethod"] as! String
            let statusName = responseData["statusName"] as! String
            
            let taxAmount = responseData["taxAmount"] as! String
            let subTotal = responseData["subTotal"] as! String
            let shippingTotal = responseData["shippingTotal"] as! String
            let couponTotal = responseData["couponTotal"] as! String
            let finalTotal = responseData["finalTotal"] as! String
            
            
            let dic:[String : Any] = ["orderNo":orderNo,"orderDate":orderDate,"paymentMethod":paymentMethod,"shippingMethod":shippingMethod,"statusName":statusName,"taxAmount":taxAmount,"subTotal":subTotal,"shippingTotal":shippingTotal,"couponTotal":couponTotal,"finalTotal":finalTotal]
            
            self.orderDetails_Array = dic
            //print(self.orderDetails_Array)
            
            let products = responseData["product"] as! [[String:Any]] //
            for data in products
            {
                let productOrderId = data["productOrderId"] as! String
                let productId = data["productId"] as! String
                let name = data["name"] as! String
                let details = data["details"] as! String
                let model = data["model"] as! String
                let productImage = data["productImage"] as! String
                
                let quantity = data["quantity"] as! String
                let price = data["price"] as! String
                let total = data["total"] as! String
                
                let isReview = data["isReview"] as! String
                let rating = data["rating"] as! Int
                let prdOption = data["prdOption"] as! [[String:Any]]
                
                var prdOptionArray:[[String:Any]] = []
                for option in prdOption
                {
                    let name = option["name"] as! String
                    let value = option["value"] as! String
                    let type = option["type"] as! String
                    
                    let dic = ["name":name,"value":value,"type":type]
                    prdOptionArray.append(dic)
                }
                let dic:[String : Any] = ["productOrderId":productOrderId,"productId":productId,"name":name,"details":details,"model":model,"productImage":productImage,"quantity":quantity,"price":price,"total":total,"isReview":isReview,"rating":rating,"prdOption":prdOptionArray]
                self.product_listArray.append(dic)
            }
            
            //Amount
            let Amount = responseData["Amount"] as! [[String:Any]]
            for data in Amount
            {
                let title = data["title"] as! String
                let amount = data["amount"] as! String
                let dic = ["title":title,"amount":amount]
                self.Amount_Array.append(dic)
            }
            //Status
            let history = responseData["history"] as! [[String:Any]]
            for data in history
            {
                let status_id = data["status_id"] as! String
                let status_name = data["status_name"] as! String
                let date = data["date"] as! String
                let dic = ["status_id":status_id,"status_name":status_name,"date":date]
                self.history_Array.append(dic)
            }
           
            let shippingAddress = responseData["shippingAddress"] as! [String: Any]
            
            let firstName = shippingAddress["firstName"] as! String
            let lastName = shippingAddress["lastName"] as! String
            let company = shippingAddress["company"] as! String
            let address = shippingAddress["address"] as! String
            let city = shippingAddress["city"] as! String
            
            let postCode = shippingAddress["postCode"] as! String
            let country = shippingAddress["country"] as! String
            let state = shippingAddress["state"] as! String
            let address1 = shippingAddress["address1"] as! String
            let address2 = shippingAddress["address2"] as! String
            let phone = shippingAddress["phone"] as! String
            
            let shippingAdd_dic:[String : Any] = ["firstName":firstName,"lastName":lastName,"company":company,"address":address,"city":city,"postCode":postCode,"country":country,"state":state,"address1":address1,"address2":address2,"phone":phone]
            
            self.shippingAddress_Array = shippingAdd_dic
            
            let paymentAddress = responseData["paymentAddress"] as! [String: Any]
            
            let first_name = paymentAddress["firstName"] as! String
            let last_name = paymentAddress["lastName"] as! String
            let company_name = paymentAddress["company"] as! String
            let street_address = paymentAddress["address"] as! String
            let city_name = paymentAddress["city"] as! String
            
            let post_code = paymentAddress["postCode"] as! String
            let country_name = paymentAddress["country"] as! String
            let state_name = paymentAddress["state"] as! String
            let address_1 = paymentAddress["address1"] as! String
            let address_2 = paymentAddress["address2"] as! String
            let phone_no = paymentAddress["phone"] as! String
            
            let paymentAdd_dic:[String : Any] = ["firstName":first_name,"lastName":last_name,"company":company_name,"address":street_address,"city":city_name,"postCode":post_code,"country":country_name,"state":state_name,"address1":address_1,"address2":address_2,"phone":phone_no]
            
            self.paymentAddress_Array = paymentAdd_dic
            

                //Reloading Table Views
                DispatchQueue.main.async
                {
                    self.ordersTableView.reloadData()
                    self.statusTableView.reloadData()
                    self.ApplyApi()
                    ProgressHud.hide()
                    
                }
        }else{
            print("Comming Soon................................")
            ProgressHud.hide()
        }

        }
        
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
               // showAlertWith(title: "Error", message: errorMessage, view: self!)
                print("NOT WORKING..............")
            }
        }
        
        //Calling API
        let parameters:EIDictonary = ["order_no": self.orderId]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.orderDetails, successCall: success, failureCall: failure)
    }
}


//Applying Api on Page
extension OrderDetailsViewController
{
    func ApplyApi()
    {
        orderIdLabel.text! = "Order Id - \(orderDetails_Array["orderNo"] as! String)"

        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "yyyy-MM-dd"

        let dateFormatterPrint = DateFormatter()
        dateFormatterPrint.dateFormat = "E, MMM dd, yyyy"

        let date: NSDate? = dateFormatterGet.date(from: orderDetails_Array["orderDate"] as! String) as NSDate?
        orderDateLabel.text! = "Order on \(dateFormatterPrint.string(from: date! as Date))"
        
        billingName.text! = "\(shippingAddress_Array["firstName"] as! String)" + " " + "\(shippingAddress_Array["lastName"] as! String)"
        
        mobile.text! = shippingAddress_Array["phone"] as! String
        
        statePincode.text! = "\(shippingAddress_Array["state"] as! String)" + " - " + "\(shippingAddress_Array["postCode"] as! String)"
        
        billingFullAddress.text! = "\(shippingAddress_Array["address1"] as! String)" + ", " + "\(shippingAddress_Array["address2"] as! String)" + ", " + "\(shippingAddress_Array["address"] as! String)" + "\(shippingAddress_Array["company"] as! String)" + ", " + "\(shippingAddress_Array["city"] as! String)"
        
        orderMethod.text! = orderDetails_Array["paymentMethod"] as! String
        totalItems.text! = "( \(product_listArray.count) Items)"
        
        originalPrice.text! = orderDetails_Array["subTotal"] as! String
        discountOnOriginalPrice.text! = orderDetails_Array["couponTotal"] as! String
        totalTax.text! = orderDetails_Array["taxAmount"] as! String
        deliveryCost.text! = orderDetails_Array["shippingTotal"] as! String
        finalAmount.text! = orderDetails_Array["finalTotal"] as! String
        if orderDetails_Array["statusName"] as! String == "Canceled"{
//            orderCancelbtn.isHidden = true
            orderCancelbtn.setTitleColor(#colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1), for: .normal)
            orderCancelbtn.setTitle("Cancelled", for: .normal)
        }
        
        
//        for data in history_Array{
//            let statusDate1: NSDate? = dateFormatterGet.date(from: data["date"] as! String) as NSDate?
//            status_1Label.text! = "\(data["status_name"] as! String)" + " " + "\(dateFormatterPrint.string(from: statusDate1! as Date))"
//        }

    }
}



//ReOrder
extension OrderDetailsViewController
{
    func reOrderAPI() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            self.showSuccessToast(text:json["responseText"] as! String)
        }else{
            ProgressHud.hide()
            self.showWarningToast(text:json["responseText"] as! String)
        }
        
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
                showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
            
        }
        
        //Calling API
        let parameters:EIDictonary = ["customer": user_id,"order_id":orderId]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.reOrder, successCall: success, failureCall: failure)
       
    }
}


//Cancel Order
extension OrderDetailsViewController
{
    func cancelOrderAPI() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            self.showSuccessToast(text:json["responseText"] as! String)
            
        }else{
            ProgressHud.hide()
            self.showWarningToast(text:json["responseText"] as! String)
        }
        
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
                showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
            
        }
        
        //Calling API
        let parameters:EIDictonary = ["customer_id": user_id,"order_id":orderId]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.cancelOrder, successCall: success, failureCall: failure)
       
    }
}


