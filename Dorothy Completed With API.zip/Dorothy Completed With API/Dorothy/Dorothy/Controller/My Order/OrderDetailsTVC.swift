//
//  OrderDetailsTVC.swift
//  Dorothy
//
//  Created by Adarsh raj on 19/08/21.
//

import UIKit

class OrderDetailsTVC: UITableViewCell {

    @IBOutlet weak var productImage: UIImageView!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var productQuantity: UILabel!
    @IBOutlet weak var productSpecialPrice: UILabel!
    @IBOutlet weak var productPrice: UILabel!
    @IBOutlet weak var productView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
