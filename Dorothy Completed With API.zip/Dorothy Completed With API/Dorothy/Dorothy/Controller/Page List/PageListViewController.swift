//
//  PageListViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 19/08/21.
//

import UIKit

class PageListViewController: UIViewController {

    @IBOutlet weak var pageListTableView: UITableView!
    var list = ["About Us","Terms & Conditions","Privacy Policy","Delivery Information"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }

    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    
}

extension PageListViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = pageListTableView.dequeueReusableCell(withIdentifier: "PageListTableViewCell", for: indexPath) as! PageListTableViewCell
        cell.pageListName.text! = list[indexPath.row]
        return cell
    }
    
    
}


extension PageListViewController: UITableViewDelegate
{
    
}
