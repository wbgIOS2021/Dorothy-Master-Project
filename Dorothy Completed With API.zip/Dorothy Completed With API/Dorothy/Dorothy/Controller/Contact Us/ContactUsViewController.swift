//
//  ContactUsViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 19/08/21.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields

class ContactUsViewController: UIViewController {

    @IBOutlet weak var firstNameTF: MDCOutlinedTextField!
    @IBOutlet weak var lastNameTF: MDCOutlinedTextField!
    @IBOutlet weak var mobileNumberTF: MDCOutlinedTextField!
    @IBOutlet weak var emailAddressTF: MDCOutlinedTextField!
    @IBOutlet weak var subjectTF: MDCOutlinedTextField!
    @IBOutlet weak var messageTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDesign()
        messageTextView.layer.borderWidth = 1
        messageTextView.layer.borderColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        messageTextView.delegate = self
        messageTextView.text = "Write message here..."
        messageTextView.textColor = UIColor.darkGray
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }
    
    
    func textFieldDesign()
    {
        firstNameTF.label.text = "First name"
        firstNameTF.leadingViewMode = .always
        
        lastNameTF.label.text = "Last Name"
        lastNameTF.leadingViewMode = .always
        
        mobileNumberTF.label.text = "Mobile Number"
        mobileNumberTF.leadingViewMode = .always
        
        emailAddressTF.label.text = "Email Address"
        emailAddressTF.leadingViewMode = .always
        
        subjectTF.label.text = "Subject"
        subjectTF.leadingViewMode = .always
        
    }
    
    
    
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    
    @IBAction func sendBtn(_ sender: Any) {
    }
}

extension ContactUsViewController: UITextViewDelegate
{
    func textViewDidBeginEditing(_ textView: UITextView) {

        if messageTextView.textColor == UIColor.darkGray {
            messageTextView.text = ""
            messageTextView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {

        if messageTextView.text == "" {
            messageTextView.text = "Write message here..."
            messageTextView.textColor = UIColor.darkGray
        }
    }
}
