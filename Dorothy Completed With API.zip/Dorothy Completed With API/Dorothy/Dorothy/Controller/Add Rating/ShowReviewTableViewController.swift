//
//  ShowReviewTableViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 24/08/21.
//

import UIKit

class ShowReviewTableViewController: UITableViewController {
    
    var productReviews_Array: [[String:Any]] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productReviews_Array.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RatingTableViewCell", for: indexPath) as! RatingTableViewCell
        
        let cellData = productReviews_Array[indexPath.row]
        cell.userLabel!.text! = cellData["author"] as! String
        cell.rating.rating = Double(cellData["rating"] as! String)!
        cell.reviewText!.text! = cellData["text"] as! String
        return cell
    }
    
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
}
