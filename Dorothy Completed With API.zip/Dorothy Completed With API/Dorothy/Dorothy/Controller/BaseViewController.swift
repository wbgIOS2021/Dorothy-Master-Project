//
//  BaseViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 16/07/21.
//

import UIKit
import SideMenuSwift
import Loaf

class BaseViewController: UIViewController {
    var menuController:SideMenuController?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    

}

extension UIViewController
{
    func cartBtn()
    {
        let isLogin = getStringValueFromLocal(key: "user_id")
        if isLogin != nil{
            let cartVC = storyboard?.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
            navigationController?.pushViewController(cartVC, animated: true)
        }else
        {
            goToLogin(message: "Please login to see your cart items")
        }

    }
    func goToLogin(message:String)
    {
        showAlertWithCancel(title: "Info.", message: message, view: self, actionHandler: {
            let login = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(login, animated: true)
        })
    }
    func backBtn()
    {
        navigationController?.popViewController(animated: true)

    }
    func searchBtn()
    {
        let vC = storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        navigationController?.pushViewController(vC, animated: true)
    }
    
    func homePage()
    {
        let vC = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuController") as! SideMenuController
        self.navigationController?.pushViewController(vC, animated: true)
    }
    func checkInternet()
    {
        if Reachability.isConnectedToNetwork(){
            print("Internet Connection Available!")
        }else{
            print("Internet Connection not Available!")

            showAlertWithOK(title: "No Internet Connection", message: "Make sure your device is connected to the internet.", view: self, actionHandler: {
                self.navigationController?.popToRootViewController(animated: true)
            })
        }
    }
    
}

extension UIViewController{

    func showToast(message : String, seconds: Double){
        let alert = UIAlertController(title: "", message: nil, preferredStyle: .actionSheet
        )
        let itemView = UIView(frame:CGRect(x:0, y:0, width: UIScreen.main.bounds.size.width - 40, height:50))
        itemView.backgroundColor = #colorLiteral(red: 0.06274510175, green: 0, blue: 0.1921568662, alpha: 1)
        itemView.contentMode = .center
        itemView.layer.cornerRadius = 10
        let label = UILabel()
       
        label.text = message
        label.translatesAutoresizingMaskIntoConstraints = false

        label.textAlignment = .center
        label.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        itemView.addSubview(label)
        alert.view.addSubview(itemView)
        alert.view.alpha = 0.8
        label.centerYAnchor.constraint(equalTo: itemView.centerYAnchor).isActive = true
        label.centerXAnchor.constraint(equalTo: itemView.centerXAnchor).isActive = true
        alert.view.layer.cornerRadius = 10
        
        let height = NSLayoutConstraint(item: alert.view!, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 50)
        let width = NSLayoutConstraint(item: alert.view!, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: UIScreen.main.bounds.size.width - 40)
        alert.view.addConstraint(height)
        alert.view.addConstraint(width)
        self.present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            alert.dismiss(animated: true)
        }
    }
    func showSuccessToast(text:String)
    {
        Loaf(text, state: .success, sender: self).show(.short)
    }
    func showWarningToast(text:String)
    {
        Loaf(text, state: .success, sender: self).show(.short)
    }
 }
//MARK:- Add or Remove wishlist
extension UIViewController
{
    
    func wishlistAction(product_id:String,actionHandler:@escaping successHandlers) -> Void {
        let isLogin = getStringValueFromLocal(key: "user_id")
        if isLogin != nil{
            
        
        ProgressHud.show()

        let success:successHandler = {  response in
            ProgressHud.hide()
            let json = response as! [String : Any]
            if json["responseCode"] as! Int == 1
            {
                //let responseText = json["responseText"] as! String
                self.showSuccessToast(text:json["responseText"] as! String)
                actionHandler(response)
            }else{
                ProgressHud.hide()
                
            }
            
        }
            let failure:failureHandler = { [weak self] error, errorMessage in
                ProgressHud.hide()
                DispatchQueue.main.async {
                    showAlertWith(title: "Error", message: errorMessage, view: self!)
                }
                
            }
            
            //Calling API
            let parameters:EIDictonary = ["customer_id": getStringValueFromLocal(key: "user_id") ?? "0","product_id":product_id ]
            
            SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.addRemoveWishlist, successCall: success, failureCall: failure)
        }else
        {
            goToLogin(message: "Please login to add wishlist")
        }
    }
}

//MARK:- Add to cart
extension UIViewController
{
    
    func addCartAction(product_id:String,quantity:Int,actionHandler:@escaping successHandlers) -> Void{
        let isLogin = getStringValueFromLocal(key: "user_id")
        if isLogin != nil{
            ProgressHud.show()

            let success:successHandler = {  response in
                ProgressHud.hide()
                let json = response as! [String : Any]
                if json["responseCode"] as! Int == 1
                {
    //                self.showSuccessToast(text:json["responseText"] as! String)
                    actionHandler(response)
                }else{
                    //ProgressHud.hide()
                    showAlertWith(title: "Warning", message: json["responseText"] as! String, view: self)
                }
                
            }
                let failure:failureHandler = { [weak self] error, errorMessage in
                    ProgressHud.hide()
                    DispatchQueue.main.async {
                        showAlertWith(title: "Error", message: errorMessage, view: self!)
                    }
                    
                }
                
                //Calling API
            let parameters:EIDictonary = ["product_id": product_id,"customer_id": getStringValueFromLocal(key: "user_id") ?? "0","quantity":quantity,"option[227][]":"18","option[228]":"20"]
                
                SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.addToCart, successCall: success, failureCall: failure)
        }else
        {
            goToLogin(message: "Please login to add to cart")
        }
           
    }
    
    func addCart2(product:[String:Any],cartBtn:UIBarButtonItem)
    {
        let success:successHandler = {  response in
            let json = response as! [String : Any]
            if json["responseCode"] as! Int == 1
            {
                self.showSuccessToast(text:json["responseText"] as! String)
                self.cartCount(cartBtn: cartBtn)
                
            }else{
                self.showWarningToast(text:json["responseText"] as! String)
                self.cartCount(cartBtn: cartBtn)

            }
        }
        self.addCartAction(product_id:product["productId"] as! String, quantity:Int(product["minimum"] as! String)!,actionHandler:success)
    }
}

//Cart Count API
extension UIViewController
{
    func cartCount(cartBtn:UIBarButtonItem) -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            if json["responseData"] as! String == "0"
            {
                cartBtn.image = UIImage(named: "Vector (2)")
            }else{
                cartBtn.image = UIImage(named: "cart_full")
            }
        }else{
            ProgressHud.hide()
            
        }
        
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
                showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
            
        }
        
        //Calling API
        let parameters:EIDictonary = ["customer_id": getStringValueFromLocal(key: "user_id") ?? "0"]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.cartCount, successCall: success, failureCall: failure)
       
    }
}


