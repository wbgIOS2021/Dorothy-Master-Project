//
//  ChangePasswordViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 03/08/21.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields

class ChangePasswordViewController: UIViewController {
    @IBOutlet weak var changePassView: UIView!
    @IBOutlet weak var oldPassTF: MDCOutlinedTextField!

    @IBOutlet weak var newPassTF: MDCOutlinedTextField!
    @IBOutlet weak var confirmPassTF: MDCOutlinedTextField!
    @IBOutlet weak var cartBtn:UIBarButtonItem!

    var user_id = getStringValueFromLocal(key: "user_id") ?? "0"
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDesign()
        cartCount(cartBtn: cartBtn)
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }
    func textFieldDesign()
    {
        oldPassTF.label.text = "Old Password"
        oldPassTF.leadingView = UIImageView(image: UIImage(named: "lock"))
        oldPassTF.leadingViewMode = .always
        
        newPassTF.label.text = "New Password"
        newPassTF.leadingView = UIImageView(image: UIImage(named: "lock"))
        newPassTF.leadingViewMode = .always
        
        confirmPassTF.label.text = "Confirm Password"
        confirmPassTF.leadingView = UIImageView(image: UIImage(named: "lock"))
        confirmPassTF.leadingViewMode = .always
    }

    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    
    @IBAction func cartBtn(_ sender: Any) {
        cartBtn()
    }
    @IBAction func submitBtn(_ sender: Any) {
        if oldPassTF.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter old password", vc: self)
        }
        else if newPassTF!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter new password", vc: self)
        }
        else if confirmPassTF!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter confirm password", vc: self)
        }
        else if oldPassTF!.text! == newPassTF!.text!
        {
            Alert.showError(title: "Error", message: "Old password and new password shouldn't be same!!!", vc: self)
        }
        else if newPassTF!.text! != confirmPassTF!.text!
        {
            Alert.showError(title: "Error", message: "New Password and confirm password Not Match!!!!", vc: self)
        }else{
            changePasswordAPi()
        }
        
    }
}

//MARK:- API Calling
extension ChangePasswordViewController
{
    func changePasswordAPi() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            showAlertWithOK(title: "Success", message: "Password Changed Successfully!!!",view : self,actionHandler:{
                self.backBtn()
            })
            

        }else{
            let mess = json["responseText"] as! String
            Alert.showError(title: "Error", message: mess, vc: self)
        }

    }
        
    let failure:failureHandler = { [weak self] error, errorMessage in
        ProgressHud.hide()
        DispatchQueue.main.async {
            Alert.showError(title: "Error", message: errorMessage, vc: self!)
        }
    }
        
    //Calling API
        let parameters:EIDictonary = ["old":self.oldPassTF.text!,"new":self.newPassTF.text!,"customer_id": user_id]
    
    SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.change_password, successCall: success, failureCall: failure)
    }
}
