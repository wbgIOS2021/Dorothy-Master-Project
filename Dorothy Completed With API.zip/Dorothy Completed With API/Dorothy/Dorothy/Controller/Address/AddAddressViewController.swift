//
//  AddAddressViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 06/08/21.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields

class AddAddressViewController: UIViewController {

    
    @IBOutlet weak var firstNameTF: MDCOutlinedTextField!
    @IBOutlet weak var lastNameTF: MDCOutlinedTextField!
    @IBOutlet weak var mobileTF: MDCOutlinedTextField!
    @IBOutlet weak var addressTF1: MDCOutlinedTextField!
    @IBOutlet weak var addressTF2: MDCOutlinedTextField!
    @IBOutlet weak var streetAddressTF: MDCOutlinedTextField!
    @IBOutlet weak var countryTF: MDCOutlinedTextField!
    @IBOutlet weak var stateTF: MDCOutlinedTextField!
    @IBOutlet weak var cityTF: MDCOutlinedTextField!
    @IBOutlet weak var pincodeTF: MDCOutlinedTextField!
    @IBOutlet weak var companyTF: MDCOutlinedTextField!
    @IBOutlet weak var isDefaultAddress: UIButton!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var cartBtn:UIBarButtonItem!

    var isDefault = 1
    var pickViewValue = 1
    var country_id:String = ""
    var state_id:String = ""
    var country_data: [[String:Any]] = []
    var state_data: [[String:Any]] = []
    var user_id = getStringValueFromLocal(key: "user_id") ?? "0"
    var userdata:[String:Any] = [:]
    var addressId:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDesign()
        gettingCountries()
        pickerView.isHidden = true
        settingData()
        cartCount(cartBtn: cartBtn)
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
    }
    
    
    func textFieldDesign()
    {
        firstNameTF.label.text = "First Name"
        firstNameTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        lastNameTF.label.text = "Last Name"
        lastNameTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        mobileTF.label.text = "Mobile Number"
        mobileTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        addressTF1.label.text = "Address 1"
        addressTF1.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        addressTF2.label.text = "Address 2"
        addressTF2.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        streetAddressTF.label.text = "Street Address"
        streetAddressTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        pincodeTF.label.text = "Pincode"
        pincodeTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        countryTF.label.text = "Country "
        countryTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        
        cityTF.label.text = "City"
        cityTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        stateTF.label.text = "State"
        stateTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
        
        companyTF.label.text = "Company Name (Optional)"
        companyTF.label.textColor = #colorLiteral(red: 0.5756814477, green: 0.5819275491, blue: 0.6006658535, alpha: 1)
    }

    //Setting Data to textField when Address Update
    func settingData()
    {
        if !userdata.isEmpty{
            firstNameTF.text! = userdata["firstname"] as! String
            lastNameTF.text! = userdata["lastname"] as! String
            mobileTF.text! = userdata["phone"] as! String
            addressTF1.text! = userdata["address1"] as! String
            addressTF2.text! = userdata["address2"] as! String
            streetAddressTF.text! = userdata["strAddress"] as! String
            pincodeTF.text! = userdata["postcode"] as! String
            countryTF.text! = userdata["country"] as! String
            stateTF.text! = userdata["zone"] as! String
            cityTF.text! = userdata["city"] as! String
            companyTF.text! = userdata["company"] as! String
            country_id = userdata["countryId"] as! String
            state_id = userdata["zoneId"] as! String
            addressId = userdata["addressId"] as! String
            isDefault = userdata["defaultAddress"] as! Int
            if isDefault == 0{
                isDefaultAddress.setImage(nil, for: .normal)
            }
        }
    }
    
    
}

//MARK:- Action Buttons
extension AddAddressViewController
{
    @IBAction func backBtn(_ sender: Any) {
        backBtn()
    }
    @IBAction func cartBtn(_ sender: Any) {
        cartBtn()
    }
    @IBAction func isDefaultAddressBtn(_ sender: Any) {
        if isDefault == 0
        {
            isDefault = 1
            isDefaultAddress.setImage(UIImage(named: "Ellipse 41"), for: .normal)
        }else{
            isDefault = 0
            isDefaultAddress.setImage(nil, for: .normal)
        }
    }
    @IBAction func saveBtn(_ sender: Any) {
        if firstNameTF.text! == ""
        {
            showAlertWith(title: "Error", message: "First name is required", view: self)
        }else if lastNameTF.text! == ""
        {
            showAlertWith(title: "Error", message: "Last name is required", view: self)

        }else if mobileTF.text! == ""
        {
            showAlertWith(title: "Error", message: "Mobile name is required", view: self)

        }else if addressTF1.text! == ""
        {
            showAlertWith(title: "Error", message: "Address1 name is required", view: self)

        }else if addressTF2.text! == ""
        {
            showAlertWith(title: "Error", message: "Address2 name is required", view: self)

        }else if streetAddressTF.text! == ""
        {
            showAlertWith(title: "Error", message: "Street Address name is required", view: self)

        }else if countryTF.text! == ""
        {
            showAlertWith(title: "Error", message: "Please select Country", view: self)

        }else if stateTF.text! == ""
        {
            showAlertWith(title: "Error", message: "Please select State", view: self)

        }else if cityTF.text! == ""
        {
            showAlertWith(title: "Error", message: "City is required", view: self)

        }else if pincodeTF.text! == ""
        {
            showAlertWith(title: "Error", message: "pincode is required", view: self)

        }else if userdata.isEmpty{
            addAddress()
            self.backBtn()
        }else{
            updateAddress()
            self.backBtn()
        }
    }
 
    @IBAction func countrySelectBtn(_ sender: Any) {
        pickViewValue = 1
        pickerView.reloadAllComponents()
        pickerView.isHidden = false
        
        
        

    }
    
    @IBAction func stateSelectBtn(_ sender: Any) {
        self.gettingStates()
        pickViewValue = 2
        pickerView.reloadAllComponents()
        pickerView.isHidden = false

    }
}
//MARK:-  Picker View
extension AddAddressViewController: UIPickerViewDelegate,UIPickerViewDataSource
{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickViewValue == 1
        {
            return country_data.count
        }
         return state_data.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickViewValue == 1
        {
            return (country_data[row]["name"] as! String)

        }else{
            return (state_data[row]["name"] as! String)

        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickViewValue == 1
        {
            countryTF.text! = country_data[row]["name"] as! String
            country_id = country_data[row]["id"] as! String
            self.gettingStates()
        }else{

            stateTF.text! = state_data[row]["name"] as! String
            state_id = state_data[row]["id"] as! String
        }
        pickerView.isHidden = true

    }
}




//MARK:- Getting Country data
extension AddAddressViewController
{
    func gettingCountries() -> Void {
        ProgressHud.show()

        let success:successHandler = {  response in
            ProgressHud.hide()
            let json = response as! [String : Any]
            if json["responseCode"] as! Int == 1
            {
                let responseData = json["responseData"] as? [[String : Any]]
                for data in responseData!
                    {
                        
                        let id = data["id"] as! String
                        let name = data["name"] as! String
                    let dic:[String : Any] = ["id":id,"name":name]
                    self.country_data.append(dic)
                    }
                
                DispatchQueue.main.async
                {
                    self.pickerView.reloadAllComponents()
                    
                }
            }else{
                print("")
            }
            
        }
            let failure:failureHandler = { [weak self] error, errorMessage in
                ProgressHud.hide()
                DispatchQueue.main.async {
                    showAlertWith(title: "Error", message: errorMessage, view: self!)
                }
                
            }
            
            //Calling API
        let parameters:EIDictonary = [:]
            
            SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.countryList, successCall: success, failureCall: failure)
           
        }
    }

//MARK:- Getting State data
extension AddAddressViewController
{
    func gettingStates() -> Void {
        ProgressHud.show()
        self.state_data.removeAll()
        let success:successHandler = {  response in
            ProgressHud.hide()
            let json = response as! [String : Any]
            if json["responseCode"] as! Int == 1
            {
//                self.showSuccessToast(text:json["responseText"] as! String)
                let responseData = json["responseData"] as? [[String : Any]]
                for data in responseData!
                    {
                        
                        let id = data["id"] as! String
                        let name = data["name"] as! String
                    let dic:[String : Any] = ["id":id,"name":name]
                    self.state_data.append(dic)
                    }
                DispatchQueue.main.async
                {
                    self.pickerView.reloadAllComponents()
                    self.stateTF.text! = self.state_data[0]["name"] as! String
                    self.state_id = self.state_data[0]["id"] as! String
                }
            }else{
                print("")
            }
            
        }
            let failure:failureHandler = { [weak self] error, errorMessage in
                ProgressHud.hide()
                DispatchQueue.main.async {
                    showAlertWith(title: "Error", message: errorMessage, view: self!)
                }
                
            }
            
            //Calling API
        let parameters:EIDictonary = ["country_id":country_id]
            
            SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.stateList, successCall: success, failureCall: failure)
           
        }
}

//MARK:- Add Address
extension AddAddressViewController
{
    //Add or Remove wishlist
    func addAddress() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {

            self.showSuccessToast(text:json["responseText"] as! String)
        }else{
            //ProgressHud.hide()
            self.showWarningToast(text:json["responseText"] as! String)        }
        
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
                showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
            
        }
        
        //Calling API
        let parameters:EIDictonary = ["customer_id":user_id,"firstname":firstNameTF.text! ,"lastname":lastNameTF.text!,"company":companyTF.text!,"address_1":addressTF1.text!,"address_2":addressTF2.text!,"str_address":streetAddressTF.text!,"city":cityTF.text! ,"phone":mobileTF.text!,"postcode":pincodeTF.text!,"country_id":country_id,"state_id":state_id,"default_address":isDefault]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.addAddress, successCall: success, failureCall: failure)
       
    }
}


//MARK:- Update Address
extension AddAddressViewController
{
    //Add or Remove wishlist
    func updateAddress() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            self.showSuccessToast(text:json["responseText"] as! String)
            self.backBtn()
        }else{
            //ProgressHud.hide()
            self.showWarningToast(text:json["responseText"] as! String)
        }
        
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
                showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
            
        }
        
        //Calling API
        let parameters:EIDictonary = ["address_id":addressId,"customer_id":user_id,"firstname":firstNameTF.text! ,"lastname":lastNameTF.text!,"company":companyTF.text!,"address_1":addressTF1.text!,"address_2":addressTF2.text!,"str_address":streetAddressTF.text!,"city":cityTF.text! ,"phone":mobileTF.text!,"postcode":pincodeTF.text!,"country_id":country_id,"state_id":state_id,"default_address":isDefault]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.updateAddress, successCall: success, failureCall: failure)
       
    }
}
