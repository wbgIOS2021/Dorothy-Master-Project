//
//  MyAddressTableViewCell.swift
//  Dorothy
//
//  Created by Adarsh Raj on 14/08/21.
//

import UIKit

class MyAddressTableViewCell: UITableViewCell {
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var fullAddressLabel: UILabel!
    @IBOutlet weak var statePincodeLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var isDefaultLabel: UILabel!
    @IBOutlet weak var addressView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
