//
//  LoginViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 29/07/21.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields

class LoginViewController: UIViewController {

    @IBOutlet weak var phoneTextField: MDCOutlinedTextField!
    @IBOutlet weak var passwordTextField: MDCOutlinedTextField!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var eyeBtn: UIButton!
    var iconClick = true
    var mobile_number = ""
    var email_address = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDesign()
        
        //Status Bar
        let statusBarView = UIView(frame: CGRect(x: 0, y: 0, width:UIScreen.main.bounds.width, height: UIApplication.shared.statusBarFrame.height))
        statusBarView.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.01568627451, blue: 0.01568627451, alpha: 1)
        self.navigationController?.view.addSubview(statusBarView)
        
    }
    override var prefersStatusBarHidden: Bool{
         return false
     }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        setNeedsStatusBarAppearanceUpdate()

    }
    
    func textFieldDesign()
    {
        phoneTextField.label.text = "Phone Number / Email"
        phoneTextField.leadingView = UIImageView(image: UIImage(named: "user_icon"))
        phoneTextField.leadingViewMode = .always
        
        passwordTextField.label.text = "Password"
        passwordTextField.leadingView = UIImageView(image: UIImage(named: "lock"))
        passwordTextField.leadingViewMode = .always
        
        loginView.layer.cornerRadius = 60
        loginView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    
}
extension LoginViewController
{
    
    @IBAction func forgotPasswordBtn(_ sender: UIButton) {
        

    }
    
    @IBAction func loginBtn(_ sender: UIButton) {
        let email = validateEmailID(emailID: phoneTextField!.text!)

        if phoneTextField!.text! == ""
            {
                Alert.showError(title: "Error", message: "Please enter mobile no", vc: self)
            }
        else if passwordTextField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter password", vc: self)
            
        }
        else{
             if email == true{
                email_address = phoneTextField!.text!
                mobile_number = ""
            }else{
                mobile_number = phoneTextField!.text!
                email_address = ""
            }
            loginAPi()
        }
    }
    
    @IBAction func signupBtn(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SendOtpViewController") as! SendOtpViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func eyeButtonAction(_ sender: Any) {
        if(iconClick == true) {
            passwordTextField.isSecureTextEntry = false
            eyeBtn.setBackgroundImage(UIImage(named: "eye"), for: UIControl.State.normal)

                } else {
                    passwordTextField.isSecureTextEntry = true
                    eyeBtn.setBackgroundImage(UIImage(named: "eye_hide"), for: UIControl.State.normal)
                }

                iconClick = !iconClick
    }
    
    @IBAction func backBtn(_ sender: UIButton) {
       backBtn()
    }

}
//MARK:- Validations on text field
extension LoginViewController
{
    func validateEmailID(emailID:String) -> Bool {
        
        let emailString = emailID.replacingOccurrences(of: " ", with: "")
        if emailString.count == emailID.count {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            return emailTest.evaluate(with: emailID)
        }else
        {
            return false
        }
    }
    
}

//MARK:- API Calling
extension LoginViewController
{
    func loginAPi() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as! [String: Any]
            
            saveStringOnLocal(key: "user_id", value: responseData["id"] as! String)
            let name = "\(responseData["firstName"] as! String)"+" \(responseData["lastName"] as! String)"
            saveStringOnLocal(key: "name", value: name)
            saveStringOnLocal(key: "profile_pic", value: responseData["profileImage"] as! String)
            
            // redirect to home page
            self.homePage()

        }else{
            let mess = json["responseText"] as! String
            Alert.showError(title: "Error", message: mess, vc: self)
        }

    }
        
    let failure:failureHandler = { [weak self] error, errorMessage in
        ProgressHud.hide()
        DispatchQueue.main.async {
           // showAlertWith(title: "Error", message: errorMessage, view: self!)
            //self!.showError(title: "Error", message: errorMessage)
            Alert.showError(title: "Error", message: errorMessage, vc: self!)
        }
    }
        
    //Calling API
    let parameters:EIDictonary = ["email": email_address,"phone":mobile_number,"password": passwordTextField.text!,"device_type": "A","device_token":"12345"]
    
    SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.user_login, successCall: success, failureCall: failure)
    }
}


