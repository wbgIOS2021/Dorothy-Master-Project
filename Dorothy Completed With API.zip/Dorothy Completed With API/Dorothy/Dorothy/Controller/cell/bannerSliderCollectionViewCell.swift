//
//  bannerSliderCollectionViewCell.swift
//  Dorothy
//
//  Created by Adarsh Raj on 25/07/21.
//

import UIKit

class bannerSliderCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var sliderView: UIView!
    @IBOutlet weak var sliderImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
