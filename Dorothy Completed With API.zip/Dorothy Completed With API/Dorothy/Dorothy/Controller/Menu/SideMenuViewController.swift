//
//  SideMenuViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 16/07/21.
//

import UIKit
import SideMenuSwift
//enum Menus:Int{
//    case homePage=0, myProfile=1, allCategory=2, wishlistPage=3, cartPage=4, contactUs=5, pageList=6
//
//}


class SideMenuViewController: UIViewController {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var menuTable: UITableView!
    @IBOutlet weak var checkLoginBtn: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var menuView:UIView!
    @IBOutlet weak var upperSectionView: UIView!
    
    var menuItems = [["name":"Home","image":#imageLiteral(resourceName: "home_icon"),"page_id":""],["name":"My Profile","image":#imageLiteral(resourceName: "user1-1"),"page_id":""],["name":"All category","image":#imageLiteral(resourceName: "category_icon"),"page_id":""],["name":"Wishlist","image":#imageLiteral(resourceName: "wishlist_icon"),"page_id":""],["name":"Cart","image":#imageLiteral(resourceName: "cart_icon2"),"page_id":""],["name":"Contact Us","image":#imageLiteral(resourceName: "support"),"page_id":""]]
    var user_pic:String = getStringValueFromLocal(key: "profile_pic") ?? "user1"
    override func viewDidLoad() {
        super.viewDidLoad()
        //profileImage.layer.cornerRadius = 30
        gettingData()
        addingSomeEffect()
        menuTable.dataSource = self
        menuTable.delegate = self
        
        profileImage.layer.cornerRadius = profileImage.frame.size.width / 2
        profileImage.clipsToBounds = true
                
        let isLogin = getStringValueFromLocal(key: "user_id")
        if isLogin != nil{
            checkLoginBtn.isHidden = true
        }else
        {
            checkLoginBtn.isHidden = false
        }
        
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        user_pic = getStringValueFromLocal(key: "profile_pic") ?? "user1"
        let url = URL(string: user_pic)
        profileImage.kf.setImage(with: url, placeholder: UIImage(named: "user1"))
        nameLabel!.text! = "Welcome \(getStringValueFromLocal(key: "name") ?? "Guest")"

    }
    
    func addingSomeEffect()
    {
//        //Some shadow on view
//        menuView.layer.shadowColor = UIColor.gray.cgColor
//        menuView.layer.shadowOpacity = 0.45
//        menuView.layer.shadowRadius = 2
//        menuView.layer.shadowOffset = CGSize(width: 0, height: 1)
        
        //For Upper view
        let rectShape = CAShapeLayer()
        rectShape.bounds = self.upperSectionView.frame
        rectShape.position = self.upperSectionView.center
        rectShape.path = UIBezierPath(roundedRect: self.upperSectionView.bounds, byRoundingCorners: [.bottomRight], cornerRadii: CGSize(width: 50, height: 50)).cgPath

        //self.upperSectionView.layer.backgroundColor = #colorLiteral(red: 0.2196078449, green: 0.007843137719, blue: 0.8549019694, alpha: 1)
        //Here I'm masking the textView's layer with rectShape layer
        self.upperSectionView.layer.mask = rectShape
    }
}

// MARK:Menu View
extension SideMenuViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = menuTable.dequeueReusableCell(withIdentifier: "SideMneuTableViewCell", for: indexPath) as! SideMneuTableViewCell
        
        let cellData = menuItems[indexPath.row]
        cell.menuTitleLabel!.text! = cellData["name"] as? String ?? "...."
        cell.menuImage.image = (cellData["image"] as! UIImage)
        return cell
    }
    
    
    
}

extension SideMenuViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        self.revealViewController().revealToggle(animated: true)
//        let appDel = UIApplication.shared.delegate as! AppDelegate

        switch indexPath.row{
        
        case 0:
            print(menuItems[indexPath.row])
            sideMenuController?.hideMenu()
//            appDel.drawerController.setDrawerState(.closed, animated: true)
           
        case 1:
            
            let isLogin = getStringValueFromLocal(key: "user_id")
            if isLogin != nil{
                sideMenuController?.hideMenu()
                let vc = storyboard?.instantiateViewController(withIdentifier: "MyProfileViewController") as! MyProfileViewController
                navigationController?.pushViewController(vc, animated: true)
            }else
            {
                goToLogin(message: "Please login to see your profile")
            }
            
        case 2:
           // self.revealViewController().revealToggle(animated: true)
            sideMenuController?.hideMenu()
//            appDel.drawerController.setDrawerState(.closed, animated: true)
            let vc = storyboard?.instantiateViewController(withIdentifier: "CategoriesTableViewController") as! CategoriesTableViewController
            navigationController?.pushViewController(vc, animated: true)
//            appDel.drawerController.mainViewController = vc
            
        case 3:
            
            let isLogin = getStringValueFromLocal(key: "user_id")
            if isLogin != nil{
                sideMenuController?.hideMenu()
                let vc = storyboard?.instantiateViewController(withIdentifier: "WishlistTableViewController") as! WishlistTableViewController
                navigationController?.pushViewController(vc, animated: true)
            }else
            {
                goToLogin(message: "Please login to see your wishlist products")
            }
            
        case 4:
            sideMenuController?.hideMenu()
            cartBtn()
        
        case 5:
            sideMenuController?.hideMenu()
            let vc = storyboard?.instantiateViewController(withIdentifier: "ContactUsViewController") as! ContactUsViewController
            navigationController?.pushViewController(vc, animated: true)
            
//        case 6:
//            sideMenuController?.hideMenu()
//            let vc = storyboard?.instantiateViewController(withIdentifier: "PageListViewController") as! PageListViewController
//            navigationController?.pushViewController(vc, animated: true)
        
        default:
            sideMenuController?.hideMenu()
            let vc = storyboard?.instantiateViewController(withIdentifier: "PageDescriptionViewController") as! PageDescriptionViewController
            let cellData = menuItems[indexPath.row]
            vc.page_id = cellData["page_id"] as! String
            navigationController?.pushViewController(vc, animated: true)
        }
        
    }
}
extension SideMenuViewController
{
    @IBAction func loginbtn(_ sender:UIButton)
    {
        let login = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(login, animated: true)
    }
}


extension SideMenuViewController
{
    func gettingData() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in

        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as? [[String : Any]]
            var i = 0
            let iconLists = [#imageLiteral(resourceName: "information-desk"),#imageLiteral(resourceName: "terms"),#imageLiteral(resourceName: "compliant"),#imageLiteral(resourceName: "delivery")]
            for data in responseData!
                {
                    
                    let name = data["name"] as! String
                    
                    let page_id = data["page_id"] as! String

                
                    let dic:[String : Any] = ["name":name,"image":iconLists[i],"page_id":page_id]
                    i += 1
                    self.menuItems.append(dic)
                }
                
                //Reloading Table Views And Collection View
                DispatchQueue.main.async
                {
                    ProgressHud.hide()
                    self.menuTable.reloadData()
//                    print("menuItems------------->>>>>",self.menuItems)
                }
        }else{
            ProgressHud.hide()
            print("Comming Soon................................")
        }
    }
        let failure:failureHandler = { [weak self] error, errorMessage in
            ProgressHud.hide()
            DispatchQueue.main.async {
               // showAlertWith(title: "Error", message: errorMessage, view: self!)
            }
        }
        
        //Calling API
        let parameters:EIDictonary = [:]
        
        SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.pageLists, successCall: success, failureCall: failure)
    }

}
