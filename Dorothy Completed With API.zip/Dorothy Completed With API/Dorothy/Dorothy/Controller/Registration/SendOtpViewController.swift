//
//  SendOtpViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 30/07/21.
//

import UIKit

class SendOtpViewController: UIViewController {

    @IBOutlet weak var sectionView: UIView!
    @IBOutlet weak var countryCodeBtn: UIButton!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var textFieldView: UIView!
    var country_code:String = "+91"
    var isLoggedUser = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        sectionView.layer.cornerRadius = 60
        sectionView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        textFieldView.layer.borderWidth = 1
        textField.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        
        //Status Bar
        let statusBarView = UIView(frame: CGRect(x: 0, y: 0, width:UIScreen.main.bounds.width, height: UIApplication.shared.statusBarFrame.height))
        statusBarView.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.01568627451, blue: 0.01568627451, alpha: 1)
        self.navigationController?.view.addSubview(statusBarView)

    }
    override var prefersStatusBarHidden: Bool{
         return false
     }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        setNeedsStatusBarAppearanceUpdate()

    }

    @IBAction func countryCodeBtnAction(_ sender: UIButton) {
        country_code = sender.titleLabel!.text!
    }
    @IBAction func sendOtpBtnAction(_ sender: Any) {
        let mobile = validateNumber(textField.text!)
        if textField.text! == ""
        {
            Alert.showError(title: "Error", message: "Enter mobile number", vc: self)
        }else if mobile == false || textField.text?.count != 10
        {
            Alert.showError(title: "Error", message: "Invalid mobile", vc: self)
        }
        else if isLoggedUser == 1{
            change_phonenoOTPAPi()
        }
        else{
            sendOTPAPi()
        }
        }
    @IBAction func backBtn(_ sender: UIButton) {
       backBtn()
    }
    
}
//MARK:- Validations on text field
extension SendOtpViewController
{
   
      func validateNumber(_ number: String) -> Bool {
        let usernameRegEx = "^[0-9]+$"
        let usernameValidator = NSPredicate(format: "SELF MATCHES %@", usernameRegEx)
        return usernameValidator.evaluate(with: number)
    }
}
//MARK:- API Calling
extension SendOtpViewController
{
    func sendOTPAPi() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            //let responseData = json["responseData"] as! [String: Any]
            
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "VerifyOtpViewController") as! VerifyOtpViewController
            vC.mobile = self.textField.text!
            vC.country_code = self.country_code
            vC.otp = json["responseData"] as! String
            self.navigationController?.pushViewController(vC, animated: true)

        }else{
            let mess = json["responseText"] as! String
            Alert.showError(title: "Error", message: mess, vc: self)
        }

    }
        
    let failure:failureHandler = { [weak self] error, errorMessage in
        ProgressHud.hide()
        DispatchQueue.main.async {
           // showAlertWith(title: "Error", message: errorMessage, view: self!)
            //self!.showError(title: "Error", message: errorMessage)
            Alert.showError(title: "Error", message: errorMessage, vc: self!)
        }
    }
        
    //Calling API
    let parameters:EIDictonary = ["code": country_code,"mobile_no":textField.text!]
    
    SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.sendOTP, successCall: success, failureCall: failure)
    }
}


//MARK:- API Calling
extension SendOtpViewController
{
    func change_phonenoOTPAPi() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            //let responseData = json["responseData"] as! [String: Any]
            
            let vC = self.storyboard?.instantiateViewController(withIdentifier: "VerifyOtpViewController") as! VerifyOtpViewController
            vC.mobile = self.textField.text!
            vC.country_code = self.country_code
            vC.otp = json["responseData"] as! String
            vC.isLoggedUser = 1
            self.navigationController?.pushViewController(vC, animated: true)

        }else{
            let mess = json["responseText"] as! String
            Alert.showError(title: "Error", message: mess, vc: self)
        }

    }
        
    let failure:failureHandler = { [weak self] error, errorMessage in
        ProgressHud.hide()
        DispatchQueue.main.async {
           // showAlertWith(title: "Error", message: errorMessage, view: self!)
            //self!.showError(title: "Error", message: errorMessage)
            Alert.showError(title: "Error", message: errorMessage, vc: self!)
        }
    }
        
    //Calling API
        let parameters:EIDictonary = ["code": country_code,"customer_id":getStringValueFromLocal(key: "user_id") ?? "0","phone_no":textField.text!]
    
    SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.change_phoneno, successCall: success, failureCall: failure)
    }
}


