//
//  RegistrationViewController.swift
//  Dorothy
//
//  Created by Adarsh Raj on 29/07/21.
//

import UIKit
import MaterialComponents.MaterialTextControls_OutlinedTextFields

class RegistrationViewController: UIViewController {

    @IBOutlet var firstNameField: MDCOutlinedTextField!
    @IBOutlet var lastNameField: MDCOutlinedTextField!
    @IBOutlet var mobileNumberField: MDCOutlinedTextField!
    @IBOutlet var emailField: MDCOutlinedTextField!
    @IBOutlet var passwordField: MDCOutlinedTextField!
    @IBOutlet var confirmPasswordField: MDCOutlinedTextField!
    @IBOutlet weak var signupView: UIView!
    var mobile:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldDesign()
        mobileNumberField.text! = mobile
        mobileNumberField.isUserInteractionEnabled = false

        signupView.layer.cornerRadius = 60
        signupView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        //Status Bar
        let statusBarView = UIView(frame: CGRect(x: 0, y: 0, width:UIScreen.main.bounds.width, height: UIApplication.shared.statusBarFrame.height))
        statusBarView.backgroundColor = #colorLiteral(red: 0.9647058824, green: 0.01568627451, blue: 0.01568627451, alpha: 1)
        self.navigationController?.view.addSubview(statusBarView)

    }
    override var prefersStatusBarHidden: Bool{
         return false
     }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
        setNeedsStatusBarAppearanceUpdate()

    }
    
    func textFieldDesign()
    {
        firstNameField.label.text = "First Name"
        firstNameField.leadingView = UIImageView(image: UIImage(named: "user_icon"))
        firstNameField.leadingViewMode = .always
        
        lastNameField.label.text = "Last Name"
        lastNameField.leadingView = UIImageView(image: UIImage(named: "user_icon"))
        lastNameField.leadingViewMode = .always
        
        mobileNumberField.label.text = "Phone Number"
        mobileNumberField.leadingView = UIImageView(image: UIImage(named: "phone"))
        mobileNumberField.leadingViewMode = .always
        
        emailField.label.text = "Email"
        emailField.leadingView = UIImageView(image: UIImage(named: "at"))
        emailField.leadingViewMode = .always
        
        passwordField.label.text = "Password"
        passwordField.leadingView = UIImageView(image: UIImage(named: "lock"))
        passwordField.leadingViewMode = .always
        
        confirmPasswordField.label.text = "Confirm Password"
        confirmPasswordField.leadingView = UIImageView(image: UIImage(named: "lock"))
        confirmPasswordField.leadingViewMode = .always
    }
    
}

extension RegistrationViewController
{
    @IBAction func loginBtn(_ sender: UIButton) {
        let vC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vC, animated: true)

    }
    
    @IBAction func signupBtn(_ sender: UIButton) {
        let email = validateEmailID(emailID: emailField!.text!)
        
        if firstNameField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter first Name", vc: self)
        }
        else if lastNameField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter last Name", vc: self)
        }
        
        else if emailField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter email", vc: self)
        }
        else if email == false
        {
            Alert.showError(title: "Error", message: "Invalid email", vc: self)
        }
        else if passwordField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter password", vc: self)
        }
        else if confirmPasswordField!.text! == ""
        {
            Alert.showError(title: "Error", message: "Please enter confirm password", vc: self)
        }
        else if passwordField!.text! != confirmPasswordField!.text!
        {
            Alert.showError(title: "Error", message: "Password and Confirm Password Not Match!!!!", vc: self)
        }else{
            registerAPi()
        }
    }
    
}

//MARK:- Validations on text field
extension RegistrationViewController
{
    func validateEmailID(emailID:String) -> Bool {
        
        let emailString = emailID.replacingOccurrences(of: " ", with: "")
        if emailString.count == emailID.count {
            let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
            return emailTest.evaluate(with: emailID)
        }else
        {
            return false
        }
    }
}
//MARK:- API Calling
extension RegistrationViewController
{
    func registerAPi() -> Void {
    ProgressHud.show()

    let success:successHandler = {  response in
        ProgressHud.hide()
        let json = response as! [String : Any]
        if json["responseCode"] as! Int == 1
        {
            let responseData = json["responseData"] as! [String: Any]
            
            saveStringOnLocal(key: "user_id", value: responseData["id"] as! String)
            let name = "\(self.firstNameField.text!)"+" \(self.lastNameField.text!)"
            saveStringOnLocal(key: "name", value: name)
            
            self.homePage()
            
        }else{
            let mess = json["responseText"] as! String
            Alert.showError(title: "Error", message: mess, vc: self)
        }

    }
        
    let failure:failureHandler = { [weak self] error, errorMessage in
        ProgressHud.hide()
        DispatchQueue.main.async {
           // showAlertWith(title: "Error", message: errorMessage, view: self!)
            //self!.showError(title: "Error", message: errorMessage)
            Alert.showError(title: "Error", message: errorMessage, vc: self!)
        }
    }
        
    //Calling API
        print("----------------------------",passwordField!.text!)
        let parameters:EIDictonary = ["firstname": firstNameField!.text!,"lastname":lastNameField!.text!,"email": emailField!.text!,"telephone": mobileNumberField!.text!,"password":passwordField!.text!,"newsletter":"1"]
    
    SERVICE_CALL.sendRequest(parameters: parameters, httpMethod: "POST", methodType: RequestedUrlType.user_register, successCall: success, failureCall: failure)
    }
}



