//
//  Constant.swift
//  Homofy
//
//  Created by Apple on 30/08/20.
//  Copyright © 2020 IT Professional Hub. All rights reserved.
//

import Foundation
import UIKit
@IBDesignable class TextFieldDesign: UITextField {
    
    @IBInspectable var borderWidt : CGFloat = 0.0 {
        didSet {
               layer.borderWidth = borderWidt
           }
    }
    
    @IBInspectable var borderColor: UIColor? {
        didSet {
            layer.borderColor = borderColor?.cgColor
        }
    }
    
    @IBInspectable var cournerRadius : CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = self.cournerRadius
            self.layer.shadowColor = UIColor.black.cgColor
            self.layer.shadowOffset = CGSize(width: 0, height: 1.0)
            self.layer.shadowOpacity = 0.2
            self.layer.shadowRadius = 4.0
            
        }
    }
    
    @IBInspectable var rightSideImage:UIImage? {
        didSet {
            updateRightView()
        }
    }
    
    @IBInspectable var leftSideImage:UIImage? {
        didSet {
            updateleftView()
        }
    }
    
    func updateRightView() {
        //for right Image
        if let image = rightSideImage {
            let imageContainerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 44, height: 20))
            let imageView = UIImageView(frame: CGRect(x: 10, y: 0, width: 18, height: 18))
            imageView.image = image
            imageContainerView.addSubview(imageView)
            rightView = imageContainerView
            rightViewMode = .always
        } else {
            rightViewMode = .never
        }
    }
    
    func updateleftView() {
        //for left Image
        if let image = leftSideImage {
            let imageContainerView: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 20))
            let imageView = UIImageView(frame: CGRect(x: 30, y: 0, width: 18, height: 18))
            imageView.image = image
            imageContainerView.addSubview(imageView)
            leftView = imageContainerView
            leftViewMode = .always
            self.tintColor = .lightGray
        } else {
            leftViewMode = .never
        }
    }
    
}

extension UITextField {

    enum PaddingSide {
        case left(CGFloat)
        case right(CGFloat)
        case both(CGFloat)
    }

    func addPadding(_ padding: PaddingSide) {

        self.leftViewMode = .always
        self.layer.masksToBounds = true


        switch padding {

        case .left(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            self.leftView = paddingView
            self.rightViewMode = .always

        case .right(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            self.rightView = paddingView
            self.rightViewMode = .always

        case .both(let spacing):
            let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: spacing, height: self.frame.height))
            // left
            self.leftView = paddingView
            self.leftViewMode = .always
            // right
            self.rightView = paddingView
            self.rightViewMode = .always
        }
    }
}

@IBDesignable class ButtonDesign: UIButton {
    
    @IBInspectable var borderWidths : CGFloat = 0.0 {
        didSet {
            self.layer.cornerRadius = self.borderWidths
        }
    }
    
    @IBInspectable var borderColor : UIColor = .clear {
        didSet {
            self.layer.borderColor = self.borderColor.cgColor
        }
    }
    
    @IBInspectable var shodow : CGFloat = 0 {
        didSet {
            self.layer.masksToBounds = false
            self.layer.shadowOffset = CGSize.init(width: 0, height: 3)
            self.layer.shadowColor = UIColor.black.cgColor
            self.layer.shadowRadius = 2.0
            self.layer.shadowOpacity = 0.35
            
            let backgroundCGColor = backgroundColor?.cgColor
            backgroundColor = nil
            self.layer.backgroundColor =  backgroundCGColor
            
        }
    }
    
}
@IBDesignable class ViewDesign: UIView {
    
    @IBInspectable var borderWid : CGFloat = 0.0 {
        didSet {
            self.layer.cornerRadius = self.borderWid
        }
    }
    
    @IBInspectable var borderColor : UIColor = .clear {
        didSet {
            self.layer.borderColor = self.borderColor.cgColor
        }
    }
    
    @IBInspectable var shodow : CGFloat = 0 {
        didSet {
            self.layer.shadowColor = UIColor.black.cgColor
            self.layer.shadowOffset = CGSize(width: 2, height: 3)
            self.layer.masksToBounds = false
            self.layer.shadowOpacity = 0.3
            self.layer.shadowRadius = 3
            self.layer.rasterizationScale = UIScreen.main.scale
            self.layer.shouldRasterize = true
            self.layer.cornerRadius = 20
            
        }
    }
    
}
